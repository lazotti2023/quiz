print("Bem vindo ao Quiz da Vanessa Lazotti")
answer_user = input("Vamos começar? (S/N)")
print(answer_user)

if answer_user != "S":
  quit()

score = 0

print("Começando...")
print("De quem é a famosa frase “Penso, logo existo”? \n (A)Platão \n (B)Galileu Galilei \n (C)Descartes")
answer_1 = input("Resposta: ")

if answer_1 == "C":
  print("Voce acertou!")
  score = score + 1
else:
  print("Que pena, voce errou!")

print("Qual o maior animal terrestre? \n (A) Elefante africano \n (B)Tubarão Branco \n (C)Girafa")
answer_2 = input("Resposta: ")

if answer_2 == "A":
  print("Voce acertou!")
  score = score + 1
else:
  print("Que pena, voce errou!")

print("Complete o provérbio “A cavalo dado …” \n (A)não se olha o rabo \n (B)bonito lhe parece \n (C)não se olha os dentes")
answer_3 = input("Resposta: ")

if answer_3 == "C":
  print("Voce acertou!")
  score = score + 1
else:
  print("Que pena, voce errou!")

print(f"O quiz acabou...vamos ver sua pontuação: {score}/3")
  
  


